package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Calculator
 */
@WebServlet("/Calculator")
public class CalculatorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CalculatorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	int num1 = Integer.valueOf(request.getParameter("num1"));
	int num2 = Integer.valueOf(request.getParameter("num2"));
	int value = 0;
	response.setContentType("text/html;charset=UTF-8");
	PrintWriter pw = response.getWriter();
	try {
		 if(request.getParameter("calc").equals("+")) {
			 value = num1+num2;
		 } else if(request.getParameter("calc").equals("-")) {
			 value=num1-num2;
		 } else if(request.getParameter("calc").equals("*")) {
			 value=num1*num2;
		 } else if(request.getParameter("calc").equals("/")) {
			 value=num1/num2;
		 }
		 System.out.println("계산 결과 : " + value);
		 pw.println("제출 완료");
		 pw.close();
	} catch(ArithmeticException a) {
		pw.println("0으로 수를 나눌 수 없습니다.");
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
